package LabAdvJava3;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class WriteDemo {
    public static void main(String[] args) {
        int b;
        b='A';
        System.out.write(b);
        System.out.println("\n");
    }
}
