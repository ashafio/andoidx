package shafijava;

public class Main {

    public static void main(String[] args) {
        Bird b = new Ostrich();
        b.fly();
        b.run();
    }
}

