package shafijava;

public class Ostrich extends Bird{
    void run()
    {
        System.out.println("Ostrich can Run");
    }
    void fly()
    {
        System.out.println("Ostrich can't fly" );
    }

}
