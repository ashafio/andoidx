package shafi;
public class Player {
    String playerName;
    int jerseyNumber;
    Player(String playerName,int jerseyNumber)
    {
        this.playerName=playerName;
        this.jerseyNumber=jerseyNumber;
    }
}
 /*
    Name: Md.Abidur Rahman Shafi
    ID:2012020121
    Section: C
    Email: cse_2012020121@lus.ac.bd
    Date: 11/09/2021
 
    */