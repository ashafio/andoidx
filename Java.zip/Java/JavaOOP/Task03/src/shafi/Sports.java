package shafi;
public class Sports {
    Sports()
    {
        System.out.println("Sports class called");
    }
}
 /*
    Name: Md.Abidur Rahman Shafi
    ID:2012020121
    Section: C
    Email: cse_2012020121@lus.ac.bd
    Date: 11/09/2021
    */




