package shafi;
public class Main {
    public static void main(String[] args) {
    Cricket cricket = new Cricket();
    cricket.matchType="International match";
    cricket.over=20;
    cricket.player="Shakib";
    Player player=new Player();
    player.jerseyNumber=75;
    void display();
       System.out.println("Jersey number of a player: "+player.jerseyNumber);
        Football football=new Football();
        }
    }
    /*
    Name: Md.Abidur Rahman Shafi
    ID:2012020121
    Section: C
    Email: cse_2012020121@lus.ac.bd
    Date: 11/09/2021
    */

