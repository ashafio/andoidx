package orionshafi.com.main;
    class Main{
    int x=10;
    public static void main(String[] args)
    {
        Main main = new main();
        System.out.println(main.x);
    }
}
