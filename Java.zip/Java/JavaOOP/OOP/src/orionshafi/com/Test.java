package orionshafi.com;
public class Test{
    int x=10;
    public static void main(String[] args)
    {
        Test test = new Test();
        System.out.println(test.x);
    }
}
