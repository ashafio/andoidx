package bookbd;

public class Main {

    public static void main(String[] args) {
        // write your code here
        //Code 01
//        if(8>=6)
//        {
//            System.out.println("Hello Maria");
//        }
//        else if(9==9)
//        {
//            System.out.println("Hello Robert");
//        }
//        else
//        {
//            System.out.println("Hello Youtube");
//        }


/*
 //Code 02
        int overtime =80;
        int pay_amt;
        int medical;
        if(overtime<=50)
        {
            pay_amt =1200;
            medical =1000;
            System.out.println("Pay Amount : "+pay_amt + " \nMedical: " + medical);
        }
        else
        {
            pay_amt=2000;
            medical=1500;
            System.out.println("Pay Amount : "+pay_amt + "\nMedical: " + medical);
        }


 */

      //Code 03
/*
        char grade = 'F';
        switch(grade)
        {
            case 'A':
                System.out.println("Comment: Excellent");
                break;

            case 'B':
                System.out.println("Comment: Good");
                break;

            case 'C':
                System.out.println("Comment: Not Bad");
                break;

            case 'D':
                System.out.println("Comment: Poor");
                break;

            case 'F':
                System.out.println("Comment: Oops!!! You're fail. Need to retake.");
                break;

            default:
                System.out.println("Comment: Invalid");
        }
        System.out.println("Your grade is: "+ grade);


 */





    }
}
