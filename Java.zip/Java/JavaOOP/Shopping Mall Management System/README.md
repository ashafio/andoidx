# Shopping_Mall_Management_System_Java
This is a Shopping Mall Management Project where using Object Oriented programming language. It is a console based project. This project will provide a smoothing experience for customers. In this project seller can assign product details. So buyer can find the product easily by searching in our system.
