package oop;

public class Main extends Home{

    public static void main(String[] args) {
        /*
        CreateFile createFile = new CreateFile();
        createFile.createFile();
        */

        // From here the project starts
        Home home = new Home();
        home.startOfEverything();
    }
}
