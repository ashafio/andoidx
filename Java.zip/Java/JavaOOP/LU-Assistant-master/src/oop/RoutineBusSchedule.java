package oop;

public class RoutineBusSchedule {
    // This function gives updated class routine
    void routine()
    {
        System.out.println("Click here to download class routine.");
    }
    // This function gives updated bus schedule
    void schedule()
    {
        System.out.println("Click here to download bus schedule.");
    }
}
