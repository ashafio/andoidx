package shafi;

public class Info{
    String name="Md.Abidur Rahman Shafi ";
    int id=2012020121;
   /* public static void main(String[] args){
    } */
}

/*
Name: Md.Abidur Rahman Shafi
ID:2012020121
Section:C

E-mail:
Academic: cse_2012020121@lus.ac.bd
NonAcademic: abidurrahman780@gmail.com

Date:13/07/2021
 */