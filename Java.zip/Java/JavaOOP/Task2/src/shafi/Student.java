package shafi;
public class Student {
    String name;
    int id;
    static String universityName="Leading University";
    Student()
    {
        System.out.println("\nStudent Info: ");
    }
    public void Student(String name) {
        this.name=name;
    public void Student(int id){
        this.id=id;
    }
    void display()
    { 
        System.out.println("Name of the university: "+universityName);
    }
}

/*
---------------------------------------
Name: Md. Abidur Rahman Shafi
ID: 2012020121
Section: C (53rd)
Email: cse_2012020121@lus.ac.bd
Date: 08 August 2021
---------------------------------------
 */