package anis;

public class Main {

    public static void main(String[] args) {
	// write your code here
        boolean x;

        x=true;

        int first_num = 21+20;
        System.out.println(first_num);
        System.out.println(x);

    }
}
