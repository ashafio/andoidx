package shafi;
import java.math.BigInteger;
public interface AdvancedArithmetic {
    int divisorSum(int num);
    BigInteger findFactorial(int num);
}
/*
Name: Md.Abidur Rahman Shafi
ID: 2012020121 (Section: C)
email: cse_2012020121@lus.ac.bd
Date: 16 Oct 2021
 */

