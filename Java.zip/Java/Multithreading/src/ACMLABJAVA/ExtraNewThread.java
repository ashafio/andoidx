package ACMLABJAVA;

public class ExtraNewThread extends Thread{


}
