package shafiswingjava;

import javax.swing.*;
import java.awt.*;

public class Jlvl extends JFrame {

    private Container c,d;

    private JLabel userLabel;
    private JLabel passLabel;
    private Font f; //importing font object


    Jlvl()
    {
//        initcomponents();
//        components_dark();
    }

    public void initcomponents()
    {
        c = getContentPane();
        c.setBackground(Color.WHITE);
        c.setLayout(null);
//Setting font
        f = new Font("Bradley Hand ITC Regular",Font.BOLD,14);

        userLabel = new JLabel();
        userLabel.setText("Enter your username: ");
        userLabel.setBounds(160,100,250,50);
        userLabel.setForeground(Color.BLACK); //works
        userLabel.setFont(f);
//foreground color change
        userLabel.setForeground(Color.yellow);

        userLabel.setOpaque(true);
        userLabel.setBackground(Color.black);

        c.add(userLabel);

//        passLabel = new JLabel("Password: "); //another method to enter text in jframe
        //is not working
        d=getContentPane();
        d.setBackground(Color.WHITE);
        d.setLayout(null);
        passLabel = new JLabel();
        passLabel.setText("Enter your Password: ");
        passLabel.setBounds(160,150,250,20);
        passLabel.setForeground(Color.yellow); //works

        passLabel.setOpaque(true);
        passLabel.setBackground(Color.black);

        passLabel.setFont(f);
        d.add(passLabel);

    }
    //for dark theme
    public void components_dark()
    {
        c = getContentPane();
        c.setBackground(Color.BLACK);
        c.setLayout(null);
        userLabel = new JLabel();
        userLabel.setText("Enter your username: ");
        //userLabel.imageUpdate("", 300,100,100,100,100);
        //userLabel.getBackground();
        userLabel.setBounds(160,50,150,50);
        userLabel.setForeground(Color.WHITE); //works
        c.add(userLabel);

    }


    public static void main(String[] args) {
        //Main Frame
        Jlvl frame = new Jlvl();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,500,400);
        frame.setTitle("Information");


            ///User Side Copy
        int optionValue = JOptionPane.showConfirmDialog(null,"Do you want to keep this default theme (White)"," ",JOptionPane.YES_NO_CANCEL_OPTION);

        if ( optionValue == JOptionPane.YES_OPTION)
        {
            JOptionPane.showMessageDialog(null,"It will take a while. Please wait.");
            //Thread.sleep(2000); //To wait sometime
            //It'll give a sound
            //Toolkit.getDefaultToolkit().beep();

            frame.initcomponents();

            JOptionPane.showMessageDialog(null,"Theme Successfully saved.");
        }
        else if(optionValue == JOptionPane.NO_OPTION)
        {
            try{
                JOptionPane.showMessageDialog(null,"It will take a while. Please wait.");
                Thread.sleep(2000); //To wait sometime
                //It'll give a sound
                //Toolkit.getDefaultToolkit().beep();

                frame.components_dark();

                JOptionPane.showMessageDialog(null,"Theme Successfully saved.");
            }catch (InterruptedException e)
            {
                System.out.println(e);
            }
        }
        else
        {
            int optionValue2 = JOptionPane.showConfirmDialog(null,"Oops!!! :( \n Something went wrong.\nDo you want to find the problem using our 'BugKill' tool?"," ",JOptionPane.YES_NO_CANCEL_OPTION);

            if (optionValue2==JOptionPane.YES_OPTION)
            {
                JOptionPane.showMessageDialog(null,"It will take a while. Please wait.");
                //Thread.sleep(2000); //To wait sometime
                //It'll give a sound
                Toolkit.getDefaultToolkit().beep();
                JOptionPane.showMessageDialog(null,"Update this application.Thank You for staying with us." );
            }
            else {
                //to give error alert
                final Runnable runnable =
                        (Runnable) Toolkit.getDefaultToolkit().getDesktopProperty("win.sound.exclamation");
                if (runnable != null) runnable.run();

                JOptionPane.showMessageDialog(null,"We're sorry.Something went wrong. BugKill did not find it. :(");

            }

//            JOptionPane.showMessageDialog(null,"Oops!!! :( \n Something went wrong.\n" +
//                    "Do you want to find the problem using our 'bugkill' tool?");

        }



        //End of selecting
//            Jlvl frame = new Jlvl();
//            frame.setVisible(true);
//            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame.setBounds(200,50,500,400);
//            frame.setTitle("Information");


    }


}
