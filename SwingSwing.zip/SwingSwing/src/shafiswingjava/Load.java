package shafiswingjava;

import javax.swing.*;

public class Load {
    private JButton button1;
    private JPanel panel1;
}
