package shafiswingjava;

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
public class jdbc {


    public static void main(String[] args) throws ClassNotFoundException, SQLException {


//        int id = Integer.parseInt(JOptionPane.showInputDialog("ID: "));
////        int ID = getInt(id);
//        String f_name = JOptionPane.showInputDialog("Enter Your First Name: ", "Your First Name");
////        String fname = r.getString(f_name);
//        String l_name = JOptionPane.showInputDialog("Enter Your Last Name: ", "Your Last Name");
////        String lname = r.getString(l_name);

//            String dbURL = "jdbc:mysql://localhost:3306/jdbctry";
        try {
            String password = "";
            String username = "root";
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost/jdbctry", "root", "");
            System.out.print("Database is connected !");
            conn.close();
            if (conn != null) {
                System.out.println("Success");
            }
            String query = "select * from user";
            var statement = conn.prepareStatement(query);
            ResultSet r = statement.executeQuery();
            while (r.next()) {
//                int ID = r.getInt("id: ");
//                String fname = r.getString("First Name: ");
//                String lname = r.getString("Last Name: ");
                // System.out.println("3s%-15s%-15s%",ID,fname,lname);
                int id = Integer.parseInt(JOptionPane.showInputDialog("ID: "));
                int ID = r.getInt(id);
                String f_name = JOptionPane.showInputDialog("Enter Your First Name: ", "Your First Name");
                String fname = r.getString(f_name);
                String l_name = JOptionPane.showInputDialog("Enter Your Last Name: ", "Your Last Name");
                String lname = r.getString(l_name);
                //String lname = JOptionPane.showInputDialog(null, "Enter Your Last Name: ", "Info", JOptionPane.QUESTION_MESSAGE);
                JOptionPane.showMessageDialog(null, "Hey " + f_name + " " + l_name + "  Welcome To JavaApp");
            }
        } catch (Exception e) {
            System.out.print("Do not connect to DB - Error:" + e);
        }
//        String f_name = JOptionPane.showInputDialog("Enter Your First Name: ","Your First Name");
//        String l_name = JOptionPane.showInputDialog(null,"Enter Your Last Name: ","Info",JOptionPane.QUESTION_MESSAGE);
//        JOptionPane.showMessageDialog(null,"Hey " + f_name + " " + l_name + "  Welcome To JavaApp");
    }
}





