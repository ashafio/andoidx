package shafiswingjava;
import javax.swing.*;
import javax.swing.JOptionPane;
public class Re1 {

    

}
